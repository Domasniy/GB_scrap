# -*- coding: utf-8 -*-
import scrapy

from scrapy.http import HtmlResponse        #Для подсказок объекта response
from bookscrapy.items import BookscrapyItem   #Подключаем класс из items

class Book24Spider(scrapy.Spider):
    name = 'book24'
    allowed_domains = ['book24.ru']
    start_urls = ['https://book24.ru/search/?q=Программирование']

    def parse(self, response:HtmlResponse):
        #Ищем ссылку для перехода на следующую страницу 
        next_page = response.css('a.catalog-pagination__item._text.js-pagination-catalog-item::attr(href)').getall()[-1]


        #Ищем ссылки на книги
        books_links = response.css('a.book__title-link::attr(href)').getall()

        for link in books_links:
            yield response.follow(link, callback=self.book_parse)
        
        yield response.follow(next_page, callback=self.parse)
    
    def book_parse(self, response:HtmlResponse):

        book_url = response.url
        book_title = response.css('h1.item-detail__title::text').get()
        book_author = response.css('div.item-tab__chars-item')[0].css('a.item-tab__chars-link::text').getall()
        #book_price это текущая цена, либо со скидкой, либо без
        book_price = int(response.css('div.item-actions__price')[0].xpath('.//descendant-or-self::*/text()').get().replace(" ", ""))
        #book_without_discount это цена до скидки, если такая есть
        book_without_discount = int(response.css('div.item-actions__price-old::text').get()[:-2].replace(" ", "")) if response.css('div.item-actions__price-old::text').get() else None
        book_rating = float(response.css('span.rating__rate-value::text').get().replace(",", ".")) if response.css('span.rating__rate-value::text').get() else None
        yield BookscrapyItem(url=book_url, title=book_title, author=book_author, price=book_price, price_old = book_without_discount, rating = book_rating)