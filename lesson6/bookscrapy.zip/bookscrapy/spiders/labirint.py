# -*- coding: utf-8 -*-
import scrapy

from scrapy.http import HtmlResponse        
from bookscrapy.items import BookscrapyItemLabirint   

class LabirintSpider(scrapy.Spider):
    name = 'labirint'
    allowed_domains = ['labirint.ru']
    start_urls = ['https://www.labirint.ru/search/Программирование/']

    def parse(self, response:HtmlResponse):
        #Ищем ссылку для перехода на следующую страницу 
        next_page = response.css('a.pagination-next__text::attr(href)').get()


        #Ищем ссылки на книги
        books_links = response.css('a.product-title-link::attr(href)').getall()

        for link in books_links:
            yield response.follow(link, callback=self.book_parse)
        
        yield response.follow(next_page, callback=self.parse)
    
    def book_parse(self, response:HtmlResponse):

        book_url = response.url
        
        try:
            book_title = response.css('div#product-title h1::text').get().split(':')[1].strip()
        except:
            book_title = response.css('div#product-title h1::text').get()
        book_author = response.css('div.authors')[0].css('a::text').getall()
        #book_price это текущая цена, либо со скидкой, либо без
        book_price = int(response.css('span.buying-pricenew-val-number::text').get())
        #book_without_discount это цена до скидки, если такая есть
        book_without_discount = int(response.css('span.buying-priceold-val-number::text').get())
        book_rating = float(response.css('div#rate::text').get())
        yield BookscrapyItemLabirint(url=book_url, title=book_title, author=book_author, price=book_price, price_old = book_without_discount, rating = book_rating)